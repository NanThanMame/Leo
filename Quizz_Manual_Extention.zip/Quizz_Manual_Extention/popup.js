document.addEventListener('DOMContentLoaded', function() {

  const emailInput = document.getElementById('email');
  const passwordInput = document.getElementById('password');
  const saveConfigBtn = document.getElementById('saveConfig');
  const startAutoBtn = document.getElementById('startAuto');
  const stopAutoBtn = document.getElementById('stopAuto');
  const statusDiv = document.getElementById('status');
  const statsDiv = document.getElementById('stats');

  // Load saved configuration
  chrome.storage.sync.get(['email', 'password'], function(result) {
    if (result.email) emailInput.value = result.email;
    if (result.password) passwordInput.value = result.password;
  });

  // Save configuration
  saveConfigBtn.addEventListener('click', function() {
    const config = {
      email: emailInput.value,
      password: passwordInput.value
    };
    
    chrome.storage.sync.set(config, function() {
      showStatus('Configuration saved successfully!', 'success');
    });
  });

  // Start auto-solver
  startAutoBtn.addEventListener('click', function() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {action: 'start'}, function(response) {
        if (response && response.success) {
          showStatus('Auto-solver started!', 'success');
        } else {
          showStatus('Failed to start auto-solver', 'error');
        }
      });
    });
  });

  // Stop auto-solver
  stopAutoBtn.addEventListener('click', function() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {action: 'stop'}, function(response) {
        if (response && response.success) {
          showStatus('Auto-solver stopped!', 'success');
        }
      });
    });
  });

  // Update stats periodically
  setInterval(updateStats, 2000);

  function showStatus(message, type) {
    statusDiv.className = `status ${type}`;
    statusDiv.textContent = message;
    setTimeout(() => statusDiv.textContent = '', 3000);
  }

  function updateStats() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {action: 'getStats'}, function(response) {
        if (response && response.stats) {
          const stats = response.stats;
          statsDiv.innerHTML = `
            <strong>Stats:</strong><br>
            Questions: ${stats.total}<br>
            High Confidence: ${stats.high}<br>
            Medium Confidence: ${stats.medium}<br>
            Low Confidence: ${stats.low}
          `;
        }
      });
    });
  }
});