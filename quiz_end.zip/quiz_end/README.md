# Quiz Auto-Solver Chrome Extension

This Chrome extension automatically solves quiz questions using AI, converted from your Python Selenium script.

## Installation

1. Open Chrome and go to `chrome://extensions/`
2. Enable "Developer mode" (toggle in top right)
3. Click "Load unpacked" and select this folder
4. The extension icon should appear in your toolbar

## Setup

1. Click the extension icon in your toolbar
2. Enter your Groq API key (get one from https://console.groq.com/)
3. Verify your email and password are correct
4. Click "Save Configuration"

## Usage

1. Navigate to your quiz website: `https://placement.skcet.ac.in/test?id=...`
2. Click the extension icon
3. Click "Start Auto-Solver"
4. The extension will:
   - Automatically login with your credentials
   - Detect questions and options
   - Get AI answers from Groq
   - Select the best matching option
   - Click "Next" to proceed

## Features

- **Auto-login**: Automatically fills email/password and clicks login buttons
- **Question Detection**: Finds questions using multiple strategies
- **AI Integration**: Uses Groq's Llama model for intelligent answers
- **Smart Matching**: Advanced text matching to select correct options
- **Statistics**: Tracks performance and confidence levels
- **Auto-navigation**: Automatically clicks "Next" buttons

## Configuration

The extension stores your settings securely in Chrome's sync storage:
- Groq API Key (required)
- Email address
- Password

## Troubleshooting

1. **Extension not working**: Check that you're on the correct website
2. **No API responses**: Verify your Groq API key is valid
3. **Login fails**: Check your email/password in the popup
4. **Questions not detected**: The website structure may have changed

## Security Notes

- API key is stored securely in Chrome's encrypted storage
- Only works on the specified quiz website
- No data is sent to external servers except Groq API

## Differences from Python Version

- No need for ChromeDriver installation
- Runs directly in the browser
- More reliable element detection
- Better error handling
- Real-time statistics in popup